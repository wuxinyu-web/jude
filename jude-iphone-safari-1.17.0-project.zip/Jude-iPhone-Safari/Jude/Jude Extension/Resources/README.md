# 句得 · 视频英语学习

## 1.17.0：iPhone Safari 预览支持

新增 Safari 独立打包与 iOS Xcode 工程生成，手机使用视频上方、学习区下方布局，支持轻点查词和长按选句。详见 [iPhone 安装与验证说明](safari/README.md)。iPhone Chrome 不支持该扩展。真机安装需要自行选择 Apple 开发签名；未做真机验证前请按预览版使用。桌面 Chrome 安装方式保持不变。

## 1.16.6：修复上下布局视频黑屏

为 YouTube 视频外层提供明确高度，覆盖原有位置偏移；保留播放器内部的原生隐藏状态，避免遮罩盖住视频。调整字幕区比例时画面同步适配，关闭学习区后恢复网页样式。更新扩展后请刷新已有 YouTube 标签。

## 1.16.5：修复 YouTube 加载卡住

修复与旧版 YouTube Digest 同时安装时，双方反复删除和重建同名按钮的冲突。YouTube 学习按钮、笔记按钮与提示现在按扩展安装 ID 隔离，页面导航只清理自己的控件。升级后在 Chrome 扩展管理页重新加载句得，再刷新已有 YouTube 标签；不需要清除收藏或设置。


句句有所得，也希望学过能记得。支持哔哩哔哩与 YouTube 的双语字幕、词句收藏与复习。沿用橙色双字幕气泡标志。

支持 B 站 /bangumi/play/ep… 官方剧集页：剧集识别、网站字幕、播放器跳转及学习区。字幕可用性取决于当前账号和网站提供的字幕轨；官方剧集可点击按钮尝试本地英文原声转写，仅支持可公开获取的音频。

点击 B 站字幕会跳转并开始播放，字幕继续顶部跟随；翻译排版变化不再中断跟随。

点击字幕立即按该行英文顶部定位，中文紧跟在下方，不等待播放高亮刷新。

点击字幕快进成功后，自动滚动到该句并恢复播放跟随；跳转期间手动滚动则保留浏览位置。

沉浸模式跟随播放时，当前台词在工具栏下方顶部对齐，避免露出上一句译文。

收藏句子后自动回到当前播放台词；手动滚动字幕时保留浏览位置，点击“回到播放位置”恢复跟随。

1.12.1：沉浸模式隐藏片段选择器，英文字幕就绪后收起整个转写控制和完成提示区；分段控制保留在左右布局侧栏。

1.12.0：超过 3 小时的长分 P 自动划分为每段 20 分钟的学习片段（原视频不变，最多 24 小时）。从当前播放位置选择片段，只读取该段音频；可选前后片段并点击「转写本段」。已完成片段复用，字幕以原视频绝对时间合并、缓存，不覆盖其他片段。

1.11.8：本机原声下载优先常规 CDN，连接失败时尝试 B 站提供的备用地址；时长超限、音轨不可读和下载失败分别提示。超过 3 小时的合集需选择单集或较短的分 P，不会通过重试绕过限制。

1.11.7：查词浮卡右上角常驻「发音、收藏单词、关闭」，加载和失败时仍可操作。可立即发音或发起收藏；收藏中显示进度，释义成功后保存，失败可重试。

1.11.6：字幕按句子分行，短句不再拼接；缺少标点时保留原字幕段，过长的单段按短语／词边界拆开。每段英文下方配对应中文，无法精确对齐的原站中文改用现有 AI 逐段翻译。沉浸英文最大字号由 24px 缩至 20px。

1.11.5：无字幕轨的 B 站视频可点击「从英文原声生成字幕」，本机转写后自动显示中英双语；单次支持 3 小时、300 MB 以内音频。需要本地服务运行及可公开读取的英文音轨。

1.11.4：英文单词鼠标悬停立即高亮，停留 600 毫秒显示释义与收藏。拖选句子（包括跨行长难句）后，可收藏句子、解释或收藏词／短语。浮卡沿用原有定位，移入浮卡不会立即消失，点击后保留收藏成功状态。

1.11.3：沉浸区支持更自由的上下拖动（字幕约占屏幕 10%–80%，保留最小可读高度）。可拖中间手柄或视频与字幕之间的分界线，拖动跨过字幕时不会丢失；松手记住比例，双击恢复默认。仍是一行工具栏。

1.11.2：修复更新后外层旧工具栏与新版字幕区混用导致仍有两行的问题。沉浸字幕区打开时同步外层为单行，不重建播放器、不丢失字幕阅读位置。

1.11.1：沉浸工具栏合并为一行（约 40px），全屏、语言切换、拖动柄、返回侧栏、播放定位与关闭共享同一行。窄窗口缩短定位文案并保留可访问名称。

## 1.11.0：边看边转写

本地原声转写按约 30 秒音频分批发布结果，扩展先缓冲 20 句（按字幕条目计），达到后显示英文与中文对照，后续收到新结果持续补充，不再等待整集结束。不足 20 句的短视频在完成时直接显示。视频保持播放，进度说明已处理的位置；未生成部分不会伪造英文。暂停／取消后已生成字幕保留，刷新学习区可恢复任务。首次仍需下载和解码音频，识别速度取决于本机性能，不保证逐句实时。

扩展重新加载后生效；新启动的本地转写任务使用更新后的分段输出。旧的运行中任务仍按启动时的代码处理，不会被自动中断。

## 1.10.1：修复中文字幕下的语言按钮

只有中文字幕时，「中文」保持正确选中；点击「双语」直接准备或重试英文原声，不再无提示切回原文。沉浸区的原声转写状态、进度、取消与重试固定在字幕工具栏内，滚动后依然可见。完成后仍显示真实英文与原站中文，不把反译结果当作原声。

## 1.10.0：只有左右布局和字幕沉浸

右侧保留完整功能，点击顶部 ↙ 箭头把字幕放到视频下方；下方点击 ↗ 返回右侧。移除独立的复杂上下学习区，旧上下布局偏好自动转为字幕沉浸。

下方直接复用右侧字幕列表，默认双语，可切换原文／中文／双语、滚轮浏览前后字幕、定位当前播放句。鼠标悬停单词 600 毫秒可查义并收藏；悬停字幕行显示「收藏句子」，保存英文原文至句子库；划选仍可收藏词、短语或长难句。其他功能只在左右布局展示。

拖动视频与字幕的分隔线调节高度（键盘方向键也可用）。「全屏」让视频与字幕一起全屏。只有中文的 B 站视频继续自动准备真实英文原声，过程中可取消／重试，完成后自动双语。

## 1.9.2：沉浸模式自动准备英文原声

进入沉浸模式后，B 站视频若只有中文字幕，会自动连接本机转写服务，优先恢复已有任务或使用完成结果；没有任务时才开始转写。台词区显示进度，可直接取消或重试，完成后自动切换英文与原站中文对照。服务不可用会明确提示；失败或取消后当前浏览器会话不自动反复重试。不把中文反译成英文原声，不自动调用云端转写。需安装并启动本地服务，说明见 local-asr/README.md。

## 1.9.1: Direct controls and automatic bilingual immersion

Click 专心看 to enlarge the player and show synchronized English / Chinese captions. 展开字幕 returns to the full workspace; contextual 放到下方 / 收至右侧 buttons move it without a three-mode picker. Settings retain the default layout preference. Resize and fullscreen still include the captions.

Chinese appears by default, preferring native captions or prepared translations. Missing Chinese is translated through the configured DeepSeek service, one current-cue request at a time; only the latest queued cue is retained after seeking. Failures offer retry. The 双语 / 英文 button temporarily hides or reveals Chinese. Chinese-only sources still require explicit original-audio transcription and are never back-translated as original dialogue.

1.8.0 adds practice-based study goals, mutually exclusive timing, explicit continuation, summaries and local record management.

> 1.7.0：新增「布局」选择，支持左右侧栏或上下学习区。上下布局保持视频在上，学习区在下，拖动分隔线可调整高度；布局和高度保存在本机，关闭学习区恢复原网页。

> 1.6.1：字幕工具栏改为「回到播放位置」，每次点击读取当前视频时间并定位，暂停时也可用；定位失败会提示刷新视频页面。

## 1.6.0: Local original-audio ASR

Bilibili now offers explicit local Whisper transcription of English audio. Chinese source captions are never back-translated and presented as original dialogue. A paired Apple Silicon companion service is required; see [local-asr/README.md](local-asr/README.md). English ASR retains original Chinese captions for time-aligned comparison and can be reverted. Audio stays on the Mac; recognition can still make mistakes.

# Video English Study — Bilibili and YouTube (1.5.0)

The entire interface and settings are Simplified Chinese. Bilibili native captions require no Supadata key; English tracks are preferred, and missing captions or login requirements are explicit. Part numbers remain distinct in caches, collections, sessions and DOCX links. YouTube support and existing stored data remain compatible.

The return-to-playback-position button immediately recenters the current caption after manual scrolling. Study time displays minutes and seconds with one-second updates, without counting background or paused-study time.

## Install and update

Use Chrome 116 or newer. At `chrome://extensions`, enable Developer mode and choose **Load unpacked**. Select this exact directory containing `manifest.json`, or unzip the release package into a permanent folder and select that folder. Do not select its parent or the ZIP file. Keep that folder in place.

Use a separate Chrome profile for the development build. The daily-use extension and its data remain untouched. A separate extension/profile has separate storage: enter your own keys directly in its Settings page. No keys or personal data are copied automatically. Existing Notes and Vocabulary records in this extension's own storage retain their schema and IDs.

After changes, reload the extension and refresh open YouTube watch pages. The active YouTube tab only supplies video context. A background YouTube tab cannot replace it.

## Provider setup

Enter Supadata and DeepSeek API keys in Settings. Supadata retrieves native captions first; audio transcription is requested only after an explicit confirmation when native captions are unavailable. DeepSeek V4 Flash handles translation, overviews, explanations, notes, word lookup and sentence analysis. No developer server or analytics is used.

Create/manage keys at [Supadata](https://dash.supadata.ai/) and [DeepSeek](https://platform.deepseek.com/api_keys). Provider usage can incur charges; see [Supadata pricing](https://supadata.ai/pricing) and [DeepSeek pricing](https://api-docs.deepseek.com/quick_start/pricing). Hover lookup calls DeepSeek after the dwell delay; successful lookups are cached by word and context in worker memory for up to 30 minutes. Exporting Word and flipping review cards do not call an AI service. Never put keys in chat, source files or screenshots.

## Collect and organize

- In Transcript, hover over an English word for 600 ms to see its contextual meaning and IPA. Click **收藏单词** to save. Moving across words does not automatically collect them. Pronunciation uses local system voices.
- Select English text, including adjacent subtitle rows, and choose **收藏长难句**. The exact source is saved first; Chinese translation, main clause, breakdown and tags are generated afterward. A failure keeps the source and offers retry. **解释** and saving a word/phrase remain available.
- Collection works on the English original in Original and bilingual mode, not the Chinese translation or YouTube's overlaid captions.
- Library contains Vocabulary, Sentences and Notes. Search words/sentences, filter this video/all videos and review state, sort by collection time or English A–Z. Video order is available within one video. Sentence tags support grammar and expression categories independently; edit them when AI classification is inaccurate.
- Grouping may show a sentence in multiple groups. Word export deduplicates IDs. Vocabulary and Sentences each allow 500 entries; capacity errors never silently evict your collection. Old longer Vocabulary entries are not automatically reclassified.

## Study and review (1.8.0)

Study tasks default to 20 effective minutes, five distinct practiced words and two distinct practiced sentences. Word/sentence goals can be zero. Scope is the current video; this project has no segment selector. Sticky controls show task state separately from the current accounting reason, cumulative/remaining time, progress and pause/resume/end actions.

Collection is not practice. Only a submitted self-assessment (known, unsure, again) advances distinct-item goals. Opening a card or revealing its answer does not. Existing cards for this video can be reused, and repeated assessments update the pending-review state without duplicating progress. A single assessment never implies mastery.

Effective time sums mutually exclusive active review, subtitle/word operation and foreground watching, in that priority order. Operation/review expire after 60 seconds without meaningful interaction. Ordinary pointer movement is excluded. Watching requires visible, focused, playing, nonbuffering playback. Playback rate does not multiply time; seeks, offline, background, manual pause and missing heartbeats do not add credit. Reaching the time goal prompts a choice without pausing playback or capping subsequent time. All three goals must be reached before the task claims success.

Panel reopening, refresh, changed video and worker restart preserve progress but require explicit resume, without offline credit. Resume may rebind to the foreground tab showing the same video and restore saved playback position without autoplay. Ended tasks can also be continued. Summary shows real timing distribution, practiced counts, pending review and each target result. Seven-day bars have daily details; empty history shows guidance.

Records are local, versioned and retained for 90 days. Learning and Settings provide Excel (.xlsx) export and confirmed record clearing; collections, notes and library self-assessments remain intact. Legacy records retain their timing and collection fields but gain no invented practice results.

## Print Word

Library's **下载 Word** exports current filtered results or checked items, optionally combining vocabulary and sentences. Each type retains its applicable filters and ordering. The dialog shows the final item count before generation.

Choose a teaching handout with meanings/analysis, or a self-test worksheet with writing space and a separate answer section. Both are real `.docx` files, A4 portrait, black and white, with source titles/timestamps/links and page numbers. Unfinished analysis is labeled. The bundled docx 9.6.1 library generates the file on-device; no upload or remote script is involved.

## Existing reading behavior

Transcript search remains literal with previous/next match navigation, not regular expressions. Reading position for the current video is kept in session storage for up to 20 videos and disappears when the browser session ends. Overview and original Notes remain available. Ask and its optional web-search provider have been removed; obsolete provider credentials and suggestion cache fields are cleared on startup.

## Development and checks

```sh
npm ci --ignore-scripts
npm test
npm run check
npm run package
```

The extension has no application build step. Runtime modules and the browser Word library are included. `npm run vendor:docx` refreshes the vendored UMD from the exact locked docx dependency. `npm run test:browser` runs the isolated Chrome extension integration fixture; first install its browser with `npx playwright install chromium --no-shell`. Set `PLAYWRIGHT_BROWSERS_PATH` if using a custom browser cache. Test fixtures never call paid providers.

Automated tests do not prove Supadata/DeepSeek account availability. Separately test a public captioned video with your own keys after loading the extension. Model output and grammar tags may be imperfect. Screenshots, browser fixtures and sample exports belong in ignored work directories, not release packages.

MIT; original project copyright and license retained. See `PRIVACY.md`, `SECURITY.md`, `docs/ARCHITECTURE.md`, and the bundled library's `vendor/docx.LICENSE`.

## 本地转写的内存、磁盘与清理规则

识别英文原声需要临时下载音频（不是整部视频画面）并在本机运行模型，所以识别期间会占用内存和磁盘，并非完全不占资源。

- 正常完成、失败或取消后，清理该任务的临时音频；无需等视频看完。
- 转写进程退出后，操作系统释放其识别内存；浏览器和轻量本地服务仍会占用各自的运行内存。
- 识别模型保留在本机磁盘供下次复用，不会随任务删除，也不会每次重新下载。
- 字幕文本和翻译保留缓存，避免重复识别。扩展字幕缓存有效期为 30 天，按缓存读写规则淘汰；本地服务在启动时清理创建超过 7 天的任务目录，并非每天定时清理。
- 强制终止进程或异常断电可能留下临时文件；不保证异常情况下立即清理。学习记录的 90 天保留规则与字幕缓存分开，清理学习记录不会删除收藏。

加载中的简短提示会说明临时占用与自动清理，任务结束后收起，不持续占用字幕显示空间。

## 本集闯关学习（1.14.0）

自由学习、原有计时、收藏、翻卡与 Word 导出继续保留。学习页新增可选闯关区：开始前告知出题与判题会使用配置的 DeepSeek API；仅从开始后本标签页在前台播放过的英文字幕出题，优先选用适合的收藏词，再补齐目标 8 道单词和 4 道常用短语题。中文题干填写英文，每类正确率至少 75%（向上取整）通关；素材不足则减少题数并明确告知，不冒充正式四级测评。生成的答案必须出现在所引字幕中，题面不得包含英文。

未匹配预设答案的回答交给 DeepSeek 判断合理同义表达；不确定或服务失败时不计错，保存回答供重试或退出。首次成绩与错题补测分开，补测通过不意味着一次掌握。试卷成功生成后复用，重复点击合并请求；浏览器中断的请求可手动重试，服务端已经发生的费用不能保证退回。生成与判题中的退出/清空会使迟到结果失效。

闯关只限制已加入任务的标签页内的后续视频播放：本集结束、测试中或切到其他视频时暂停并显示测试/退出入口。可以在学习页结束当前观看提前测试，因此它不是完整看完一集的证明。允许退出且记为未通关；不限制关闭插件、换浏览器或新标签页，不能作为防作弊或家长控制。刷新后保留进度并需手动继续；拖动、后台、缓冲、离线和休眠不补记播放片段。

新增独立 ytd_challenges（schemaVersion 1），不改旧学习记录或收藏结构。试卷、答案、自评以外的客观练习结果、观看区间和作答仅存本机，保留 90 天（访问时清理），最多 200 次记录、每任务最多 30 次提交。原有“导出学习记录”包含闯关记录；确认清空会清理两类学习记录，但保留收藏与笔记。仅向 DeepSeek 发送选取的已观看字幕、候选收藏词、题目和待判回答，不发送其他视频或本地密钥。出题抽样最多 240 行，过长字幕提示使用较短单集。

新增 challenge-core/worker/ui/content 模块。写操作串行化，AI 请求在队列外；题目生成、判分用任务 ID 与 revision 防迟到覆盖。新数据接口仅扩展页可调用，内容脚本只能发播放采样、主动退出及打开侧栏；播放采样结合真实发送标签页和活动窗口核对。试卷初次提交前不通过页面消息返回参考答案。浏览器本机数据不提供考试级保密。

自测内容筛选：自动闯关出题和 Word 自测排除明显色情、下流、脏话及相关例句；自动出题另要求模型检查隐喻和语境。合适素材不足时减少题量，不凑题。原字幕和收藏不因此删除。规则与模型筛选不能保证识别所有隐晦表达，课堂使用前仍可复核。


## 家长模式（1.15.0）

原自由学习、收藏和普通闯关保留。家长在学习页选择“家长设置密钥”，抄下仅当次显示的 9 位数字，隐藏后重新输入确认启用。退出模式必须验证密钥；密钥不会再次显示，也没有免密解除入口。忘记密钥时不能通过本功能恢复，请妥善保存。

- 同一浏览器中扩展支持的 Bilibili / YouTube 视频页面遵循家长任务，切换标签页不会直接解除。通过后，下一个未完成视频自动建立任务；已完成的视频可以回看。
- 从启用本集任务后实际观看的英文字幕统计不同收藏项。收集 10 个单词、5 个句子并实际观看至少视频时长的 80% 可完成收集任务，记录不表示已掌握。收藏不足或观看不足则进入测试。未收藏也能从已观看字幕出题。
- 本集结束或尝试进入其他视频时，字幕素材已就绪会自动准备试卷；可以提前选择“结束观看，准备测试”。失败后提供重试，不自动循环调用收费接口。
- 家长试卷为 10 道单词中文提示默写英文（每题 0.5 分）和 5 道完整句子中译英（每题 1 分），满分 10 分，达到 8 分通过。模型优先挑选常用动词、形容词和四级及以上难度语料；这不是正式四级测评。语义相符的自然译法可以判对。
- 题干、答案及来源例句继续规避色情、下流、脏话等。可靠安全素材不足 15 题时不按小卷放行，可回看、补齐英文字幕后重试或请家长解除；不编造台词凑题。
- 未通过先逐项复习错题、自评记住，再重新作答整张试卷。整卷独立计分，首次成绩保留，不用历次正确答案累积凑够 8 分。参考原声回放限于错题对应片段。
- 判题或出题服务失败不会记为答错或自动解锁，可重试或由家长解除。出题和必要判题使用现有已配置 AI 服务，可能产生费用；不新增账号、后台或第三方分析。
- 密钥仅首次设置返回到家长界面，本机保存随机盐与 PBKDF2-SHA-256 校验值（210000 次），不保存明文；5 次错误后等待 60 秒。待确认密钥 10 分钟过期。校验信息不进入学习记录导出，保留到解除；学习记录依旧只存本机、保留 90 天。家长模式开启时，清空学习记录须先解除，不删除收藏。
- 限制范围是扩展支持的此浏览器视频页，不是系统级控制。卸载/禁用扩展、清除扩展数据、使用其他浏览器或应用仍可绕过；本机数据并非防篡改证据，不能据此保证学生专注或掌握。

Word 下载提供“纯讲义版”和“讲义＋测试题版”。后者依次包含完整讲义、另起页的中文出题英文作答测试、另起页的参考答案；测试部分继续筛选课堂适宜内容。

家长模式入口（1.15.5）：仅在学习页右上角常驻显示开关，滚动时仍可见，默认不展示家长设置大卡片；开启与解除在密钥弹窗内完成，开关只反映已确认状态。取消弹窗不解除模式。普通闯关及观看中的家长任务使用轻量状态行，直接提供继续或开始测试操作；不再使用折叠任务框。测试和错题复习需要处理时展示。确认开启可结束现有普通闯关并保留记录。

学习页顶部展示最近 7 天趋势及每日明细；计时规则、学习记录导出与清空仍位于底部。

学习记录导出为 Excel（.xlsx），含每日统计、学习任务、测试成绩和说明。时长以秒记录，保留各次实际测试成绩；不导出家长密钥或收藏正文。文件在本机生成。

## 1.16 简化学习页
自由学习页面仅显示今日有效时长、复习收藏和学习记录。打开学习区后在前台视频上自动建立计时记录，暂停与后台仍不计观看时间；无手动任务目标要求。七日记录、Excel 导出和清空移入学习记录弹窗。普通闯关入口移除，旧闯关结束但保留成绩；本集限制仅在家长模式开启时显示。跨视频收藏可以复习，自评不虚增当前视频任务成果。

## 1.16.1 家长密码与学习记录
家长自行设置 6–64 位密码，重复输入确认后直接开启，无随机密钥展示步骤。仅保存加盐哈希，旧 9 位密钥仍可用于解除。学习记录弹窗恢复最近七天柱状图，点击日期显示观看、操作和复习时长，保留 Excel 导出。

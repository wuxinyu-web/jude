# Translation Prompts

Used in `background.js` when the user requests Simplified Chinese content.

## Shared base rules

```
TRANSLATION RULES (follow strictly):
- Match the EXACT tone and register of the original (casual stays casual, formal stays formal)
- Use natural {langName} sentence structures — NOT English syntax translated word-by-word
- Do NOT translate: proper nouns, brand names, technical terms commonly kept in English (API, AI, etc.), timestamps
- Preserve ALL formatting: paragraph breaks, bullet points, markdown, timestamps
{langSpecific}
```

## Chinese rules

```
- Use modern colloquial Simplified Chinese (简体中文). Avoid stiff 书面语 unless the original is formal.
- Use natural Chinese sentence structures — do NOT mirror English syntax.
- Translate the complete thought before deciding the final Chinese phrasing; never preserve a broken caption fragment just because the source API split there.
- Use 你, never 您, unless the source is explicitly using formal honorific language.
- Write for a smart tech/product audience. Keep common terms and product names such as AI, API, GitHub, Claude Code, Codex, skill, builder, deck, and Chrome in English when that is the natural usage.
- Put readable spaces between Chinese and adjacent English words or digits, for example `使用 Claude Code` and `过去 6 个月`.
- Remove empty spoken fillers rather than translating them literally, while preserving real uncertainty or emphasis.
```

## Transcript batch translation

Input is a JSON object with 1 to 4 complete semantic transcript segments. Each
segment has a stable `id` and source-language `text`.

```
You are a professional translator. Translate the transcript segments into {langName}.
The video is titled "{videoTitle}". Use the title and neighboring segments only as context for names, pronouns, terminology, and the speaker's intended meaning.

{baseRules}

- Translate each segment as a complete spoken thought, not as isolated caption fragments.
- Use neighboring segments for context, but do not merge, split, omit, or reorder segments.
- Return a JSON object with exactly this shape: {"segments":[{"id":"unchanged-id","text":"translated text"}]}.
- Copy every input id exactly. Translate only text values.
- Output only valid JSON. No markdown fences, commentary, labels, or extra keys.
```

## Overview batch translation

Input is a JSON object with 1 to 4 overview text fields. Each field has a stable
`id` and source-language `text`.

```
You are a professional translator. Translate the video overview fields into {langName}.
The video is titled "{videoTitle}". Use the title and neighboring fields as context for names, terminology, and the intended meaning.

{baseRules}

- Preserve the distinction between summary prose, chapter labels, and direct quotes.
- Translate each field independently; do not merge, split, omit, or reorder fields.
- Return a JSON object with exactly this shape: {"segments":[{"id":"unchanged-id","text":"translated text"}]}.
- Copy every input id exactly. Translate only text values.
- Output only valid JSON. No markdown fences, commentary, labels, or extra keys.
```

## Explanation translation

Input is a JSON object with exactly one concise English explanation. The field
has the stable id `explain-0` and source-language `text`.

```
You are a professional translator. Translate the explanation into {langName}.
The video is titled "{videoTitle}". Use the title only to preserve the intended terminology and meaning.

{baseRules}

- Keep the translation as concise as the English explanation.
- Do not add facts, examples, caveats, or commentary.
- Return a JSON object with exactly this shape: {"segments":[{"id":"explain-0","text":"translated text"}]}.
- Copy the input id exactly. Translate only the text value.
- Output only valid JSON. No markdown fences, commentary, labels, or extra keys.
```

## Variables

- `{langName}` — "Simplified Chinese".
- `{baseRules}` — the shared base rules above.
- `{langSpecific}` — the Chinese rules inserted into the shared base rules.
- `{videoTitle}` — video title.
